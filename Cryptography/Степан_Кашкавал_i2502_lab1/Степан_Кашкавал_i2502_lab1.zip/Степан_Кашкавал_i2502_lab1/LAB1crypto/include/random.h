#pragma once

int randInt();
