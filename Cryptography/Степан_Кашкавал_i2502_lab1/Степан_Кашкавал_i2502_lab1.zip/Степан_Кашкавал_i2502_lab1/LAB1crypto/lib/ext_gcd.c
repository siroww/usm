
#include <stdint.h>
#include <sys/types.h>

#include "../include/math_x.h"

uint8_t* poly_ext_gcd(uint16_t a, uint16_t mod) {
    // Статический массив: память сохраняется между вызовами
    static uint8_t res[2];

    if (a == 0) { // Предотвращение зацикливания и математическая оптимизация
        res[0] = 0;
        res[1] = 0;
        return res;
    }

    uint16_t old_r = mod, r = a;
    uint16_t old_s = 0,   s = 1;

    while (r != 0) {
        uint16_t q = poly_div(old_r, r);

        // Исправлено: сначала вычисляем новый остаток с использованием старого old_r
        uint16_t temp_r = poly_xor(old_r, poly_mult(q, r));
        old_r = r;
        r = temp_r;

        // Вычисление нового коэффициента s
        uint16_t temp_s = poly_xor(old_s, poly_mult(q, s));
        old_s = s;
        s = temp_s;
    }

    res[0] = (uint8_t)old_r;
    res[1] = (uint8_t)old_s;

    return res;
}

/*
    function ext_gcd(a, b):
        old_r, r = a, b
        old_s, s = 1, 0
        while r != 0:
            q = old_r div r
            old_r, r = r, old_r - q*r
            old_s, s = s, old_s - q*s
        return old_r, old_s

    function mod_inverse(a, m):
        g, x = ext_gcd(a, m)
        if g != 1:
            error("the inverse does not exist")
        return x mod m
 */

uint16_t* ext_gcd(uint16_t a_in, uint16_t mod_in) {
    int a = a_in;
    int m = mod_in;
    int old_r = a, r = m;
    int old_s = 1, s = 0;

    static uint16_t res[2];

    if (a == 0) { // предотвращения зацикливания и математичская оптимизация
        res[0] = 0;
        res[1] = 0;
        return res;
    }

    while (r != 0) {
        uint16_t q = old_r / r;

        int temp_r = old_r;
        old_r = r;
        r = temp_r - q * r;

        int temp_s = old_s;
        old_s = s;
        s = temp_s - q * s;
    }

    res[0] = (uint16_t)old_r;
    res[1] = (uint16_t)((old_s % m + m) % m);
    return res;
}

uint16_t mod_inverse(uint16_t a, uint16_t mod) {
    uint16_t* res = ext_gcd(a, mod);
    if (res[0] != 1) {
        return 0;
    }
    return res[1];
}
